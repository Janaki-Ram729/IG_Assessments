package com.ig.model;

public class Scholar {
	private int ScholarId;
	private String Name;
	private String Email;
	private String mobile;
	
	

	public Scholar(int scholarId, String name, String email, String mobile) {
		super();
		ScholarId = scholarId;
		Name = name;
		Email = email;
		this.mobile = mobile;
	}
	
	public int getScholarId() {
		return ScholarId;
	}
	public void setScholarId(int scholarId) {
		ScholarId = scholarId;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	@Override
	public String toString() {
		return "Scholar [ScholarId=" + ScholarId + ", Name=" + Name + ", Email=" + Email + ", mobile=" + mobile + "]";
	}
	
	
	
	
}
