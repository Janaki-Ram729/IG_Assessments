package com.ig.dao;

import java.sql.SQLException;
import java.util.List;
import com.ig.exception.ScholarNotFoundException;
import com.ig.model.Scholar;

public interface ScholarDao {
	void addScholar(Scholar scholar) throws SQLException;
    Scholar getOneScholar(int scholarId) throws SQLException, ScholarNotFoundException;
    List<Scholar> listAllScholars() throws SQLException;
    void updateScholarEmail(int scholarId, String newEmail) throws SQLException, ScholarNotFoundException;
    void deleteScholarById(int scholarId) throws SQLException, ScholarNotFoundException;
}
