package com.ig.dao;

import com.ig.exception.ScholarNotFoundException;
import com.ig.model.Scholar;
import com.ig.util.DbUtil;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ScholarDaoImp implements ScholarDao {

    public void addScholar(Scholar scholar) throws SQLException {
        String sql = "INSERT INTO Scholar (Rollno, Name, Email, Mobile_no) VALUES (?, ?, ?, ?)";
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, scholar.getScholarId());
            ps.setString(2, scholar.getName());
            ps.setString(3, scholar.getEmail());
            ps.setString(4, scholar.getMobile());
            ps.executeUpdate();
        }
    }

    public Scholar getOneScholar(int scholarId) throws SQLException, ScholarNotFoundException {
        String sql = "SELECT * FROM Scholar WHERE Rollno = ?";
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, scholarId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Scholar(rs.getInt("Rollno"), rs.getString("Name"), rs.getString("Email"), rs.getString("Mobile_no"));
                } else {
                    throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
                }
            }
        }
    }

    public List<Scholar> listAllScholars() throws SQLException {
        List<Scholar> scholars = new ArrayList<>();
        String sql = "SELECT * FROM Scholar";
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                scholars.add(new Scholar(rs.getInt("Rollno"), rs.getString("Name"), rs.getString("Email"), rs.getString("Mobile_no")));
            }
        }
        return scholars;
    }

    public void updateScholarEmail(int scholarId, String newEmail) throws SQLException, ScholarNotFoundException {
        String sql = "UPDATE Scholar SET Email = ? WHERE Rollno = ?";
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, newEmail);
            ps.setInt(2, scholarId);
            int updatedRows = ps.executeUpdate();
            if (updatedRows == 0) {
                throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
            }
        }
    }

    public void deleteScholarById(int scholarId) throws SQLException, ScholarNotFoundException {
        String sql = "DELETE FROM Scholar WHERE Rollno = ?";
        try (Connection conn = DbUtil.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, scholarId);
            int deletedRows = ps.executeUpdate();
            if (deletedRows == 0) {
                throw new ScholarNotFoundException("Scholar with ID " + scholarId + " not found.");
            }
        }
    }
}

