package com.ig.ui;

import com.ig.model.Scholar;
import com.ig.service.ScholarService;
import com.ig.service.ScholarServiceImp;
import com.ig.exception.ScholarNotFoundException;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class ScholarApp{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ScholarService service = new ScholarServiceImp();
        boolean exit = false;

        while (!exit) {
            System.out.println("\n-----------Scholar Management System-----------");
            System.out.println("1. Add Scholar");
            System.out.println("2. Get Scholar by ID");
            System.out.println("3. List All Scholars");
            System.out.println("4. Update Scholar Email");
            System.out.println("5. Delete Scholar");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); 

            switch (choice) {
                case 1:
                    System.out.print("Enter Scholar ID: ");
                    int id = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    System.out.print("Enter Email: ");
                    String email = scanner.nextLine();
                    System.out.print("Enter Mobile: ");
                    String mobile = scanner.nextLine();
                    try {
                        service.addScholar(new Scholar(id, name, email, mobile));
                        System.out.println("Scholar added successfully!");
                    } catch (SQLException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 2:
                    System.out.print("Enter Scholar ID: ");
                    int searchId = scanner.nextInt();
                    try {
                        Scholar scholar = service.getOneScholar(searchId);
                        System.out.println(scholar);
                    } catch (SQLException | ScholarNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 3:
                    try {
                        List<Scholar> scholars = service.listAllScholars();
                        scholars.forEach(System.out::println);
                    } catch (SQLException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 4:
                    System.out.print("Enter Scholar ID: ");
                    int updateId = scanner.nextInt();
                    scanner.nextLine();
                    System.out.print("Enter new Email: ");
                    String newEmail = scanner.nextLine();
                    try {
                        service.updateScholarEmail(updateId, newEmail);
                        System.out.println("Email updated successfully!");
                    } catch (SQLException | ScholarNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 5:
                    System.out.print("Enter Scholar ID: ");
                    int deleteId = scanner.nextInt();
                    try {
                        service.deleteScholarById(deleteId);
                        System.out.println("Scholar deleted successfully!");
                    } catch (SQLException | ScholarNotFoundException e) {
                        System.out.println("Error: " + e.getMessage());
                    }
                    break;
                case 6:
                    exit = true;
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
        scanner.close();
    }
}
