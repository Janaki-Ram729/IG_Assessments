package com.ig.service;

import com.ig.exception.ScholarNotFoundException;
import com.ig.model.Scholar;
import java.sql.SQLException;
import java.util.List;

public interface ScholarService {
    void addScholar(Scholar scholar) throws SQLException;
    Scholar getOneScholar(int scholarId) throws SQLException, ScholarNotFoundException;
    List<Scholar> listAllScholars() throws SQLException;
    void updateScholarEmail(int scholarId, String newEmail) throws SQLException, ScholarNotFoundException;
    void deleteScholarById(int scholarId) throws SQLException, ScholarNotFoundException;
}
