package com.ig.service;


import com.ig.dao.ScholarDao;
import com.ig.dao.ScholarDaoImp;
import com.ig.exception.ScholarNotFoundException;
import com.ig.model.Scholar;

import java.sql.SQLException;
import java.util.List;

public class ScholarServiceImp implements ScholarService {
    private ScholarDao scholarDao = new ScholarDaoImp();

    public void addScholar(Scholar scholar) throws SQLException {
        scholarDao.addScholar(scholar);
    }

    public Scholar getOneScholar(int scholarId) throws SQLException, ScholarNotFoundException {
        return scholarDao.getOneScholar(scholarId);
    }

    public List<Scholar> listAllScholars() throws SQLException {
        return scholarDao.listAllScholars();
    }

    public void updateScholarEmail(int scholarId, String newEmail) throws SQLException, ScholarNotFoundException {
        scholarDao.updateScholarEmail(scholarId, newEmail);
    }

    public void deleteScholarById(int scholarId) throws SQLException, ScholarNotFoundException {
        scholarDao.deleteScholarById(scholarId);
    }
}
