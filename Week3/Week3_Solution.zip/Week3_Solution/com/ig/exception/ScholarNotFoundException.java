package com.ig.exception;

public class ScholarNotFoundException extends Exception{
	
	public ScholarNotFoundException(String msg) {
		super(msg);
	}

}
