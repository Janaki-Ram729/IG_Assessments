package Streams;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class ProductApp {
    public static void main(String[] args) {
        // Creating Suppliers
        Supplier s1 = new Supplier(1, "ABC Supplies");
        Supplier s2 = new Supplier(2, "XYZ Traders");
        Supplier s3 = new Supplier(3, "FoodMart");

        // Creating Products
        List<Product> productList = Arrays.asList(
                new Product(201, "Butter", "Dairy", 1.0, 60.0, LocalDate.of(2025, 4, 10), s1),
                new Product(202, "Lentils", "Pulses", 2.5, 180.0, LocalDate.of(2024, 3, 18), s2),
                new Product(203, "Sunflower Oil", "Oils", 1.0, 450.0, LocalDate.of(2024, 3, 5), s3),
                new Product(204, "Chocolate", "Snacks", 2.0, 150.0, LocalDate.of(2024, 3, 12), s1),
                new Product(205, "Cinnamon", "Spices", 0.3, 95.0, LocalDate.of(2024, 3, 22), s2),
                new Product(206, "Cheese", "Dairy", 0.8, 250.0, LocalDate.of(2025, 5, 30), s3),
                new Product(207, "Green Peas", "Pulses", 1.2, 210.0, LocalDate.of(2024, 3, 8), s1),
                new Product(208, "Mustard Oil", "Oils", 1.0, 520.0, LocalDate.of(2024, 4, 15), s2),
                new Product(209, "Biscuits", "Snacks", 1.5, 80.0, LocalDate.of(2024, 2, 25), s3),
                new Product(210, "Black Pepper", "Spices", 0.4, 110.0, LocalDate.of(2024, 3, 17), s1)
        );

        ProductService service = new ProductService(productList);

        System.out.println("Highest Priced Product: " + service.getHighestPricedProduct().orElse(null));
        System.out.println("Lowest Priced Product: " + service.getLowestPricedProduct().orElse(null));

        System.out.println("\n Expired Products: ");
        service.getExpiredProducts().forEach(System.out::println);

        System.out.println("\n Products Expiring in Next 10 Days: " + service.getExpiringSoonProducts());

        System.out.println("\n Product Count by Type: " + service.countProductsByType());
        System.out.println("\n Product Count by Supplier: " + service.countProductsBySupplier());
    }
}
