package Streams;

import java.time.LocalDate;
import java.util.*;
import java.util.stream.Collectors;

public class ProductService {
	    private List<Product> products;

	    public ProductService(List<Product> products) {
	        this.products = products;
	    }

	    public Optional<Product> getHighestPricedProduct() {
	        return products.stream().max(Comparator.comparing(Product::getPrice));
	    }

	    public Optional<Product> getLowestPricedProduct() {
	        return products.stream().min(Comparator.comparing(Product::getPrice));
	    }

	    public List<Product> getExpiredProducts() {
	        LocalDate today = LocalDate.now();
	        return products.stream()
	                .filter(p -> p.getExpiryDate().isBefore(today))
	                .collect(Collectors.toList());
	    }

	    public List<String> getExpiringSoonProducts() {
	        LocalDate today = LocalDate.now();
	        LocalDate tenDaysLater = today.plusDays(10);
	        return products.stream()
	                .filter(p -> p.getExpiryDate().isAfter(today) && p.getExpiryDate().isBefore(tenDaysLater))
	                .map(Product::getName)
	                .collect(Collectors.toList());
	    }

	    public Map<String, Long> countProductsByType() {
	        return products.stream()
	                .collect(Collectors.groupingBy(Product::getType, Collectors.counting()));
	    }

	    public Map<String, Long> countProductsBySupplier() {
	        return products.stream()
	                .collect(Collectors.groupingBy(p -> p.getSupplier().getSname(), Collectors.counting()));
	    }
	}
