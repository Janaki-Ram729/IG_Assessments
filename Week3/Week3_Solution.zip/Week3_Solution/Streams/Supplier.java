package Streams;

class Supplier {
    Integer id;
    String sname;

    public Supplier(Integer id, String sname) {
        this.id = id;
        this.sname = sname;
    }

    public String getSname() { return sname; }

    @Override
    public String toString() {
        return "Supplier{" + "id=" + id + ", sname='" + sname + '\'' + '}';
    }
}